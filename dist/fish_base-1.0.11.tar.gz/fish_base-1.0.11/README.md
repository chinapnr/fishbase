## fish_base 简介

这是我们在学习 python 过程中积累的一个函数库，主要用于自己项目的学习使用，希望对 python 的初学者等有所帮助。

---

帮助文档：http://fish-base.readthedocs.io/