``fish_logger`` 日志记录函数包
====================================

.. automodule:: fish_logger
   :members:
   :exclude-members: SafeFileHandler