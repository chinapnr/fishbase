``fish_file`` 文件处理函数包
================================

.. automodule:: fish_file
   :members: