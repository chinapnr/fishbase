``fish_system`` 系统相关函数包
====================================

.. automodule:: fish_system
   :members: