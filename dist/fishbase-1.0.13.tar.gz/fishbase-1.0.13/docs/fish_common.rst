``fish_common`` 基本函数包
=============================

.. autosummary::
    fish_common.conf_as_dict
    fish_common.get_uuid
    fish_common.GetMD5.string
    fish_common.GetMD5.file
    fish_common.GetMD5.big_file
    fish_common.if_json_contain
    fish_common.SingleTon
    fish_common.sorted_list_from_dict
    fish_common.splice_url_params

.. automodule:: fish_common
    :members:
