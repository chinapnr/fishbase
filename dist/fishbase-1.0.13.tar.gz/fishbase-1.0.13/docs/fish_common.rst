``fish_common`` 基本函数包
=============================

.. automodule:: fish_common
    :members:
