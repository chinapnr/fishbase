# fishbase.system demo
# 2018.5.26 created by David Yi
# for Python 3.x

from fishbase.fish_system import *

if __name__ == '__main__':
    print('current os:', get_platform())
