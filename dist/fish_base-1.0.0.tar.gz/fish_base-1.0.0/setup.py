from distutils.core import setup

setup(
    name='fish_base',
    version='1.0.0',
    packages=['fish_base'],
    url='http://chuangyiji.com',
    license='',
    author='david.yi',
    author_email='wingfish@gmail.com',
    description='some useful functions for python'
)
